/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patho;

/**
 *
 * @author vaish
 */
public class Keys {
    public static final String HOST="mail.smtp.host";
    public static final String PORT="mail.smtp.port";
    public static final String SSL_ENABLED="mail.smtp.ssl.enable";
    public static final String AUTH="mail.smtp.auth";
    public static final String APP_PASSWORD_EMAIL="pbatemen003@gmail.com";
    public static final String SOCKET_FACTORY_PORT="mail.smtp.socketFactory.port";
    public static final String SOCKET_FACTORY_CLASS="mail.smtp.socketFactory.class";
    public static final String SOCKET_FACTORY_FALLBACK="mail.smtp.socketFactory.fallback";
    public static final String OTP = "OTP";
    public static final String OTP_TIME = "OTP_TIME";
    public static final String OTP_EMAIL="OTP_EMAIL";
}
